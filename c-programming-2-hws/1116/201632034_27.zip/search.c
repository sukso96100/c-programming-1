#include<stdio.h>
#include<string.h>

typedef struct{
	int id;
	char * name;
	char * major;
}STUDENT;

int main(void){
	STUDENT students[] = {
		{201632034, "한영빈", "소프트웨어공학과"},
		{201534028, "추건우", "소프트웨어공학과"},
		{201232016, "배다슬", "소프트웨어공학과"},
		{201632032, "최강식", "소프트웨어공학과"},
		{201632033, "최준호", "소프트웨어공학과"},
		{201632035, "판사님", "소프트웨어공학과"},
		{000032034, "고양이", "소프트웨어공학과"},
		{000132034, "홍길동", "소프트웨어공학과"},
		{111132032, "임꺽정", "소프트웨어공학과"},
		{000132034, "김홍도", "소프트웨어공학과"},
	};
	char nameToSearch[20];
	int i;
	fputs("검색할 학생의 이름을 입력하세요.\n", stdout);
	fgets(nameToSearch, sizeof(nameToSearch), stdin);

	for(i=0; i<10; i++){
		if(strncmp(nameToSearch, students[i].name, sizeof(students[i].name))==0){
			printf("학번 : %d\n", students[i].id);
			printf("이름 : %s\n", students[i].name);
			printf("학과 : %s\n", students[i].major);
			return 0;
		}
	}
	
	fputs("해당 학생이 존재하지 않습니다.", stdout);
	return 0;
}